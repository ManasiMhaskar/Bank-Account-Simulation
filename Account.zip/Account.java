package com.task5;

import java.util.ArrayList;
import java.util.List;

class Account {
    private String accountNumber;
    private String accountHolderName;
    private double balance;
    private List<Transaction> transactionHistory; 

    public Account(String accountNumber, String accountHolderName, double initialBalance) {
        this.accountNumber = accountNumber;
        this.accountHolderName = accountHolderName;
        this.balance = initialBalance;
        this.transactionHistory = new ArrayList<>();
        
        transactionHistory.add(new Transaction("Account Creation", initialBalance, initialBalance));
    }

    public String getAccountNumber() {
        return accountNumber;
   }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public double getBalance() {
        return balance;
    }

    
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            transactionHistory.add(new Transaction("Deposit", amount, balance)); 
            System.out.println("Successfully deposited: $" + String.format("%.2f", amount));
        } else {
            System.out.println("Deposit amount must be positive.");
        }
    }

   
    public void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("Withdrawal amount must be positive.");
        } else if (balance >= amount) {
            balance -= amount;
            transactionHistory.add(new Transaction("Withdrawal", amount, balance)); 
            System.out.println("Successfully withdrew: $" + String.format("%.2f", amount));
        } else {
            System.out.println("Insufficient balance. Current balance: $" + String.format("%.2f", balance));
        }
    }

	public void displayAccountInfo() {
		
		
	}

	public void displayTransactionHistory() {
		
		
	}
}