package com.task5;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;


class Transaction {
    private String type;
    private double amount;
    private double newBalance;
    private Date timestamp;

    public Transaction(String type, double amount, double newBalance) {
        this.type = type;
        this.amount = amount;
        this.newBalance = newBalance;
        this.timestamp = new Date(); 
    }

   
    public String toString() {
        return "Type: " + type + ", Amount: " + String.format("%.2f", amount) + ", New Balance: " + String.format("%.2f", newBalance) + ", Date: " + timestamp;
    }
}